import numpy
import random
from sys import argv
import time
import scipy

def initialize(data, no_of_clusters):
    means = [data[0]]
    for k in range(1, no_of_clusters):
        D2 = scipy.array([min([scipy.inner(mean-x,mean-x) for mean in means]) for x in data])
        probab = D2/D2.sum()
        cumprobs = probab.cumsum()
        r = scipy.rand()
        for j,p in enumerate(cumprobs):
            if r < p:
                i = j
                break
        means.append(data[i])
    return means

def k_means(no_of_clusters, iterations, data):
	means = []
	no_of_points = len(data)

    # dict=[]
    # for i in range(no_of_clusters):
    #     x = random.randint(0,no_of_points-1)
    #     while(x in dict):
    #         x = random.randint(0,no_of_points-1)
    #     dict.append(x)
    #     means.append(data[x])

	means = initialize(data, no_of_clusters)

	#print (means)

	assigned_cluster = [0]*no_of_points

	for j in range(iterations):
		for i in range(no_of_points):
			min_dist = 1000000000.0
			for k in range(no_of_clusters):
				tmp_dist = 0.0
				for l in range(len(data[k])):
					tmp_dist+=(means[k][l]-data[i][l])*(means[k][l]-data[i][l])

				tmp_dist=numpy.sqrt(tmp_dist)

				if(tmp_dist<min_dist):
					min_dist = tmp_dist
					assigned_cluster[i] = k

		new_means = [[0]*len(data[0])]*no_of_clusters
		#print (len(new_means))
		counter = [0]*no_of_clusters
		#print (new_means)
		for i in range(no_of_points):
			for x in range(len(data[0])):
				new_means[assigned_cluster[i]][x] = new_means[assigned_cluster[i]][x]+data[i][x]

			counter[assigned_cluster[i]] = counter[assigned_cluster[i]] + 1

		#print (new_means)
		
		for i in range(no_of_clusters):
			for k in range(len(new_means[i])):
				new_means[i][k]/=counter[i]
				means[i][k]=new_means[i][k]

		#print (new_means)
		#print (counter)
		#print ('\n')

	return assigned_cluster


def write_to_file(outputfile, assigned_cluster):
	with open(outputfile, 'a') as output:
		for i in range(len(assigned_cluster)):
			output.write(str(assigned_cluster[i]) + '\n')
	output.close()
								
def read_from_file(datafile):
	with open(datafile, 'r') as inputFile:
		lines = inputFile.readlines()
	# shuffle(lines)
	data = numpy.asarray([[float(i) for i in line.split()] for line in lines])
	print ("Finished reading inputfile")
	return data

def write_to_file1(no_of_clusters,assigned_cluster,outputfile):
	x=[[]]*no_of_clusters
	no_of_points = len(assigned_cluster)
	for i in range(no_of_points):
		x[assigned_cluster[i]].append(i)
	with open(outputfile,'a') as output:
		for i in range(no_of_clusters):
			output.write("#"+str(i)+"\n")
			for j in range(len(x[i])):
				output.write(str(x[i][j])+"\n")
	output.close()



if __name__ == '__main__': 

	no_of_clusters = int(argv[1])
	inputfile = argv[2]
	#outputfile = argv[2]
	
	step0 = time.time()

	data = read_from_file(inputfile)
	assigned_cluster = k_means(no_of_clusters, 15, data)
	step1 = time.time()
	#write_to_file(outputfile, assigned_cluster)
	write_to_file1(no_of_clusters, assigned_cluster, 'kmeans.txt')

	print(step1-step0)
	