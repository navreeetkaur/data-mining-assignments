#!/bin/bash

g++ dbScan.cpp -std=c++11 -O3 -o dbscan