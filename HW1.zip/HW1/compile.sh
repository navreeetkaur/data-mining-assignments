#!/bin/bash
javac Test.java